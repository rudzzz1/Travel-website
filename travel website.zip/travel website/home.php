<!DOCTYPE html>
<html lang="en">
<head>
   <meta charset="UTF-8">
   <meta http-equiv="X-UA-Compatible" content="IE=edge">
   <meta name="viewport" content="width=device-width, initial-scale=1.0">
   <title>home</title>

   <!-- swiper css link  -->
   <link rel="stylesheet" href="https://unpkg.com/swiper@7/swiper-bundle.min.css" />

   <!-- font awesome cdn link  -->
   <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css">
   <meta charset="utf-8">
   <meta name="viewport" content="width=device-width, initial-scale=1">
   <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.6.1/dist/css/bootstrap.min.css">
   <!-- custom css file link  -->
   <link rel="stylesheet" href="css/style.css">

</head>
<body>
   
<!-- header section starts  -->

<section class="header">

   <a href="home.php" class="logo">travel.</a>

   <nav class="navbar">
      <a href="home.php">home</a>
      <a href="about.php">about</a>
      <a href="package.php">package</a>
      <a href="book.php">book</a>
      <a href="login.php">login</a>
   </nav>

   <div id="menu-btn" class="fas fa-bars"></div>

</section>

<!-- header section ends -->

<!-- home section starts  -->
<div id="carouselExampleIndicators" class="carousel slide" data-ride="carousel">
  <ol class="carousel-indicators">
    <li data-target="#carouselExampleIndicators" data-slide-to="0" class="active"></li>
    <li data-target="#carouselExampleIndicators" data-slide-to="1"></li>
    <li data-target="#carouselExampleIndicators" data-slide-to="2"></li>
    <li data-target="#carouselExampleIndicators" data-slide-to="3"></li>
    <li data-target="#carouselExampleIndicators" data-slide-to="4"></li>
    <li data-target="#carouselExampleIndicators" data-slide-to="5"></li>
  </ol>
  <div class="carousel-inner">

  <div class="carousel-item active">
  <img src="images\dubai1.jpg" alt="Dubai">
  <div class="carousel-caption d-none d-md-block">
    <h3>Dubai</h3>
    <h6>Habibi, come to Dubai</h6>
  </div>
  </div>

  <div class="carousel-item">
  <img src="images\bangkok1.jpg" alt="Bangkok">
  <div class="carousel-caption d-none d-md-block">
    <h3>Bangkok</h3>
    <h6>The City of Gods</h6>
  </div>
  </div>

  <div class="carousel-item">
  <img src="images\paris1.jpg" alt="Paris">
  <div class="carousel-caption d-none d-md-block">
    <h3>Paris</h3>
    <h6>Here, love is in the air</h6>
  </div>
  </div>

  <div class="carousel-item">
  <img src="images\kashmir1.jpg" alt="Kashmir">
  <div class="carousel-caption d-none d-md-block">
    <h3>Kashmir</h3>
    <h6>Heaven on Earth</h6>
  </div>
  </div>

  <div class="carousel-item">
  <img src="images\mauritius1.jpg" alt="Maldives">
  <div class="carousel-caption d-none d-md-block">
    <h3>Maldives</h3>
    <h6>The King's island</h6>
  </div>
  </div>

  <div class="carousel-item">
  <img src="images\los angeles1.jpg" alt="Los Angeles">
  <div class="carousel-caption d-none d-md-block">
    <h3>Los Angeles</h3>
    <h6>City of angels awaits you</h6>
  </div>
  </div>



  <a class="carousel-control-prev" href="#carouselExampleIndicators" role="button" data-slide="prev">
    <span class="carousel-control-prev-icon" aria-hidden="true"></span>
    <span class="sr-only">Previous</span>
  </a>
  <a class="carousel-control-next" href="#carouselExampleIndicators" role="button" data-slide="next">
    <span class="carousel-control-next-icon" aria-hidden="true"></span>
    <span class="sr-only">Next</span>
  </a>
</div>
</div>
<!-- home section ends -->

<!-- services section starts  -->

<section class="services">

   <h1 class="heading-title"> our services </h1>

   <div class="box-container">

      <div class="box">
         <img src="images/icon-1.png" alt="">
         <h3>adventure</h3>
      </div>

      <div class="box">
         <img src="images/icon-2.png" alt="">
         <h3>tour guide</h3>
      </div>

      <div class="box">
         <img src="images/icon-3.png" alt="">
         <h3>trekking</h3>
      </div>

      <div class="box">
         <img src="images/icon-4.png" alt="">
         <h3>camp fire</h3>
      </div>

      <div class="box">
         <img src="images/icon-5.png" alt="">
         <h3>off road</h3>
      </div>

      <div class="box">
         <img src="images/icon-6.png" alt="">
         <h3>camping</h3>
      </div>

   </div>

</section>

<!-- services section ends -->

<!-- home about section starts  -->

<section class="home-about">

   <div class="image">
      <img src="images/about-img.jpg" alt="">
   </div>

   <div class="content">
      <h3>about us</h3>
      <p>Here, you can find all the wonderful travel destinations from across the globe, with breathtaking veiws, glorious cultures, luscious foods and an overall magnificent experiences.<br>So, pack your bags to an adventure worth remembering for a lifetime.</p>
      <a href="about.php" class="btn">Read more</a>
   </div>

</section>

<!-- home about section ends -->

<!-- home packages section starts  -->

<section class="home-packages">

   <h1 class="heading-title"> Our packages </h1>

   <div class="box-container">

      <div class="box">
         <div class="image">
            <img src="images/img-1.jpg" alt="">
         </div>
         <div class="content">
            <h3>Adventure & tour</h3>
            <a href="book.php" class="btn">book now</a>
         </div>
      </div>

      <div class="box">
         <div class="image">
            <img src="images/img-2.jpg" alt="">
         </div>
         <div class="content">
            <h3>Trekking & camp fire</h3>
            <a href="book.php" class="btn">book now</a>
         </div>
      </div>
      
      <div class="box">
         <div class="image">
            <img src="images/img-3.jpg" alt="">
         </div>
         <div class="content">
            <h3>Off-road & camping</h3>
            <a href="book.php" class="btn">book now</a>
         </div>
      </div>

   </div>

</section>

<!-- home packages section ends -->

<!-- home offer section starts  -->

<section class="home-offer">
   <div class="content">
      <h3>upto 50% off</h3>
      <p>Offer ends soon! Grab it fastt!!</p>
      <a href="book.php" class="btn">book now</a>
   </div>
</section>

<!-- home offer section ends -->





<!-- footer section starts  -->

<section class="footer">

   <div class="box-container">

      <div class="box">
         <h3>quick links</h3>
         <a href="home.php"> <i class="fas fa-angle-right"></i> home</a>
         <a href="about.php"> <i class="fas fa-angle-right"></i> about</a>
         <a href="package.php"> <i class="fas fa-angle-right"></i> package</a>
         <a href="book.php"> <i class="fas fa-angle-right"></i> book</a>
      </div>

      <div class="box">
         <h3>More links</h3>
         <a href="#"> <i class="fas fa-angle-right"></i> ask questions</a>
         <a href="#"> <i class="fas fa-angle-right"></i> about us</a>
      </div>

      <div class="box">
         <h3>Contact us</h3>
         <a href="#"> <i class="fas fa-phone"></i> +91 456565345 </a>
         <a href="#"> <i class="fas fa-phone"></i> +91 567543546 </a>
         <a href="#"> <i class="fas fa-envelope"></i> travelworld@gmail.com </a>
         <a href="#"> <i class="fas fa-map"></i> Mumbai, india - 400101 </a>
      </div>

      <div class="box">
         <h3>follow us</h3>
         <a href="https://instagram.com/meer_suhil?igshid=YmMyMTA2M2Y="> <i class="fab fa-facebook-f"></i> facebook </a>
         <a href="https://instagram.com/rudzzz___?igshid=YmMyMTA2M2Y="> <i class="fab fa-instagram"></i> instagram </a>
      </div>

   </div>

   <div class="credit"> Created by <span>Mr. Mir and Mr. Mahajan </span> </div>

</section>

<!-- footer section ends -->





   <script src="https://cdn.jsdelivr.net/npm/jquery@3.6.0/dist/jquery.slim.min.js"></script>
   <script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.1/dist/umd/popper.min.js"></script>
   <script src="https://cdn.jsdelivr.net/npm/bootstrap@4.6.1/dist/js/bootstrap.bundle.min.js"></script>





<!-- swiper js link  -->
<script src="https://unpkg.com/swiper@7/swiper-bundle.min.js"></script>

<!-- custom js file link  -->
<script src="js/script.js"></script>

</body>
</html>