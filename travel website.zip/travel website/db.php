<?php

$conn =Imysqli_connect("localhost", "homestead", "secret", "packetcode-test");

if(!$conn) {

echo "<h3 class='container my-3 text-center bg-dark text white rounded-Lg p-3'>Unable to establish connection to Database</h3>";
}

?>