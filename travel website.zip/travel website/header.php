<?php

   if (!empty($SESSION['username'])){?>

      header('location:book.php'); 

   }else{
      echo 'Please login for booking!';
   }

?>