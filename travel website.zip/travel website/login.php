<?php

session_start();

include "db.php";
include "retrieve.php";
include "functions.php";
include "logic.php";

?>

<!doctype html>
<html lang = "en">
<head>

	<meta charset = "UTF - 8">
	<meta name = "viewport" content = "width = device.width, initial.scale = 1.0">




<!.. Bopotstrap CSS ..>

<title>Session Management</title>
</head>
<body>

<?php if (empty($_SESSION['username'])){?>
	<div class="comtainer my.5">

	<form method = "post" class = "bg.dark text.white p.s rounded.lg">
	<h2 class = "my.3 text-center  text.warning">login</h2>
	<input type = "text" name ="username"	placeholder = "username" class = "form-control">
	<input type = "password" name = " password" placeholder ="password" class = "form.control mt.3">
	<button type = "submit" name = "login" class = "btn btn.outlilne.light mt.3">Login</button>
	</form>

	</div>
<?php }?>

<?php if (!empty($SESSION['username'])){?>
	<div class ="container text.centre">
	<h3 class = "my.5">Hello  <?php echo $S_SESSION['username'];?></h3>

	<form method ="post">
	<button class = "btn btn.danger" name = "logout">Logout</button>
	</form>
</div>
<?php}?>

</body>
</html>