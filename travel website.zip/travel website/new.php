<!DOCTYPE html>
<html lang="en">
<head>
   <meta charset="UTF-8">
   <meta http-equiv="X-UA-Compatible" content="IE=edge">
   <meta name="viewport" content="width=device-width, initial-scale=1.0">
   <title>home</title>

   <!-- swiper css link  -->
   <link rel="stylesheet" href="https://unpkg.com/swiper@7/swiper-bundle.min.css" />

   <!-- font awesome cdn link  -->
   <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css">
   <meta charset="utf-8">
   <meta name="viewport" content="width=device-width, initial-scale=1">
   <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.6.1/dist/css/bootstrap.min.css">
   <!-- custom css file link  -->
   <link rel="stylesheet" href="css/style.css">

</head>
<body>
   
<!-- header section starts  -->

<section class="header">

   <a href="home.php" class="logo">travel.</a>

   <nav class="navbar">
      <a href="home.php">home</a>
      <a href="about.php">about</a>
      <a href="package.php">package</a>
      <a href="book.php">book</a>
   </nav>

   <div id="menu-btn" class="fas fa-bars"></div>

</section>

<!-- header section ends -->

<!-- home offer section starts  -->

<section class="home-offer">
   <div class="content">
      <h3>Booking done successfully</h3>
      <p>You'll recieve the tickets via mail soon</p>
      <a href="home.php" class="btn">Back to homepage</a>
   </div>
</section>

<!-- home offer section ends -->





<!-- footer section starts  -->

<section class="footer">

   <div class="box-container">

      <div class="box">
         <h3>quick links</h3>
         <a href="home.php"> <i class="fas fa-angle-right"></i> home</a>
         <a href="about.php"> <i class="fas fa-angle-right"></i> about</a>
         <a href="package.php"> <i class="fas fa-angle-right"></i> package</a>
         <a href="book.php"> <i class="fas fa-angle-right"></i> book</a>
      </div>

      <div class="box">
         <h3>More links</h3>
         <a href="#"> <i class="fas fa-angle-right"></i> ask questions</a>
         <a href="#"> <i class="fas fa-angle-right"></i> about us</a>
      </div>

      <div class="box">
         <h3>Contact us</h3>
         <a href="#"> <i class="fas fa-phone"></i> +91 456565345 </a>
         <a href="#"> <i class="fas fa-phone"></i> +91 567543546 </a>
         <a href="#"> <i class="fas fa-envelope"></i> travelworld@gmail.com </a>
         <a href="#"> <i class="fas fa-map"></i> Mumbai, india - 400101 </a>
      </div>

      <div class="box">
         <h3>follow us</h3>
         <a href="https://instagram.com/meer_suhil?igshid=YmMyMTA2M2Y="> <i class="fab fa-facebook-f"></i> facebook </a>
         <a href="https://instagram.com/rudzzz___?igshid=YmMyMTA2M2Y="> <i class="fab fa-instagram"></i> instagram </a>
      </div>

   </div>

   <div class="credit"> Created by <span>Mr. Mir and Mr. Mahajan </span> </div>

</section>

<!-- footer section ends -->





   <script src="https://cdn.jsdelivr.net/npm/jquery@3.6.0/dist/jquery.slim.min.js"></script>
   <script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.1/dist/umd/popper.min.js"></script>
   <script src="https://cdn.jsdelivr.net/npm/bootstrap@4.6.1/dist/js/bootstrap.bundle.min.js"></script>





<!-- swiper js link  -->
<script src="https://unpkg.com/swiper@7/swiper-bundle.min.js"></script>

<!-- custom js file link  -->
<script src="js/script.js"></script>

</body>
</html>